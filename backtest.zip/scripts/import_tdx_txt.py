from __future__ import annotations

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from data_store import MarketDataStore


def parse_args():
    parser = argparse.ArgumentParser(description="Import TDX TXT files into the standard market cache.")
    parser.add_argument("--txt-dir", type=Path, default=Path("data"))
    parser.add_argument("--market-cache-dir", type=Path, default=Path("data/market_cache/daily_bars_by_symbol"))
    parser.add_argument("--start-date", type=str, default=None)
    parser.add_argument("--end-date", type=str, default=None)
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    store = MarketDataStore(args.txt_dir, args.market_cache_dir)
    report = store.import_txt_files(start_date=args.start_date, end_date=args.end_date, overwrite=args.overwrite)
    print("========== Import completed ==========")
    for key, value in report.items():
        if key != "failures":
            print(f"{key}: {value}")
    if report["failures"]:
        print("Failures:")
        for item in report["failures"][:20]:
            print(f"  - {item['file']}: {item['error']}")


if __name__ == "__main__":
    main()
